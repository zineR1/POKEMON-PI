'use strict';

var express = require('express');
var router = express.Router();
router.use(express.json());

var tareas = []

// escriban sus rutas acá 
// siéntanse libres de dividir entre archivos si lo necesitan




module.exports = {
    router, 
    tareas
};