import React from 'react';

export function Todos() {
  return (
    <div>
      Componente Todos
    </div>
  )
};

export default Todos;