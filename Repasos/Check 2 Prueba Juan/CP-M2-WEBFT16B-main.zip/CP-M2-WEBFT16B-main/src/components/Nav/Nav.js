import React from 'react';

export function Nav() {
  return (
    <div>
      Componente Nav
    </div>
  )
};

export default Nav;