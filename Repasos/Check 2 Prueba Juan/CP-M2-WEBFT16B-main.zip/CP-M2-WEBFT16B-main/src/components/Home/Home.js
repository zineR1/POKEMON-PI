import React from 'react';

export function Home() {
  return (
    <div>
      Componente Home
    </div>
  )
};

export default Home;