import React from 'react'
import './App.css';


// En este componente deberias cargar tus rutas.
export function App() {
  return (
    <div className="App">
      Checkpoint M2
    </div>
  );
}

export default App;
