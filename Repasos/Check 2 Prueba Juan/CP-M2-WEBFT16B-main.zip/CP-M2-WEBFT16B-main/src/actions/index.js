// Podes usar esta variable para generar un ID por cada Todo.
let todoId = 1

export const addTodo = undefined;

export const removeTodo = undefined

export const toInProgress = undefined;

export const toDone = undefined;